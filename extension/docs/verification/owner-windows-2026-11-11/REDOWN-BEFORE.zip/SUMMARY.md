# REDOWN diagnostic summary

Scope: Local stored metadata only: no background activation or provider probes; volatile/uncommitted observations and current writer readiness are unavailable
Collection: 2026-11-11T15:11:10.933Z

## Provider transitions
- google: 24 rows; failure codes {"SOURCE_RETURNED_HTML":4,"PROVIDER_FAILED":1}; last verified receipt 0ec2afe5-343a-4b18-bfbb-f9f28e5f9f4b at 2026-11-11T13:18:44.615Z; first later failure 5e47f36b-8497-461f-8bf4-87fd6ffdc790 at 2026-11-11T13:19:22.633Z.
- dropbox: 24 rows; failure codes {"PROVIDER_FAILED":3,"SOURCE_RETURNED_HTML":4}; last verified receipt b9c57201-8120-4c63-b0de-ff95ae8690a7 at 2026-11-11T13:19:59.560Z; first later failure unavailable.
- onedrive: 15 rows; failure codes {"PROVIDER_FAILED":8}; last verified receipt 3a3369dd-745d-4b37-a987-36ea62ed5eaf at 2026-11-11T13:17:36.516Z; first later failure ee556c9d-a2e4-4ea0-b407-04ddc74ab97b at 2026-11-11T13:18:06.079Z.
- cloudflare: 9 rows; failure codes {"PROVIDER_FAILED":2}; last verified receipt 1f2c266f-e1da-400e-9e13-083813b1132c at 2026-11-11T15:09:11.010Z; first later failure unavailable.

## Correlations and missing evidence
- 0 observed queue/phase stalls; no automatic retry was triggered.
- 24 attempt-only rows; 0 incomplete traces.
- 48 attempts have no source fingerprint; cross-provider asset matches are unavailable for those attempts.
- Storage unavailable: none observed; trace persistence stored-only.
- Archive read: read.
- Source IDs are installation-keyed HMACs over the exact source URL without fragment. Raw origins, paths, query values and the key are omitted. Changed query values, including rotated signatures, do not match. Matching IDs do not prove unchanged file bytes.
- A missing click cannot establish whether Chrome failed to deliver it or collection was unavailable.
- Stages and local receipts do not prove live provider acceptance. Remote objects must be checked separately.
- Same sourceId can correlate attempts across providers; unknown IDs are evidence gaps, not inferred matches.

## Same-asset observations
- Asset e5397e861bc0: cloudflare UNCERTAIN 4a2099a5-a1fc-49de-80c6-4af7cca088a8.
- Asset 8c73aa6e42d1: cloudflare COMPLETED 1f2c266f-e1da-400e-9e13-083813b1132c.
