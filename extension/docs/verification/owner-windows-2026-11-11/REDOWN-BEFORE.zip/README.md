# Sharing this diagnostic ZIP

Review before sharing: timestamps, provider names, statuses, error codes, safe HTTP header categories, aggregate counters and opaque attempt/source IDs are included. No file contents, filenames, account/destination identifiers, OAuth tokens, cookies, signed URLs or source/page URLs are exported.

Unzip locally and begin with SUMMARY.md, then join attempts.json, queue.json and source-and-provider-failures.json by attempts.id / attemptId. Missing sources/stages and partial storage are explicit evidence gaps. This download is local and triggers no provider requests, repairs or automatic uploads.

Never add credentials or private URLs to this archive. A fresh remote readback or installed-Chrome reproduction must be recorded separately before claiming live acceptance.
