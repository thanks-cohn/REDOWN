# REDOWN diagnostic summary

Scope: Local stored metadata only: no background activation or provider probes; volatile/uncommitted observations and current writer readiness are unavailable
Collection: 2026-11-11T17:07:30.972Z

## Provider transitions
- google: 27 rows; failure codes {"UNCONFIRMED":1}; last verified receipt f41ddbf0-6195-49b2-9b14-94d212819058 at 2026-11-11T16:40:01.099Z; first later failure b9649090-7bec-4cea-af4e-81aac03ed017 at 2026-11-11T16:40:02.399Z.
- dropbox: 25 rows; failure codes {"HISTORY_UNAVAILABLE":1,"UNCONFIRMED":1}; last verified receipt 7652a91e-f1f6-4696-9741-638ea7b39d57 at 2026-11-11T16:38:20.452Z; first later failure f0ac60a1-ec89-49de-90cb-4d7d16bf58df at 2026-11-11T16:39:38.037Z.
- onedrive: 28 rows; failure codes {"ONEDRIVE_BUSY":3,"HISTORY_UNAVAILABLE":2,"UNCONFIRMED":1}; last verified receipt ba7fed51-e389-4b1b-ae61-5915cb72c9c5 at 2026-11-11T16:37:19.343Z; first later failure 9e068028-b6c6-4916-8ff0-0e4f601485f4 at 2026-11-11T16:38:00.845Z.
- cloudflare: 20 rows; failure codes {"PROVIDER_FAILED":20}; last verified receipt unavailable; first later failure 4443b0ae-697e-498c-8006-8f0810af75c3 at 2026-11-11T16:23:26.854Z.

## Correlations and missing evidence
- 4 observed queue/phase stalls; no automatic retry was triggered.
- 50 attempt-only rows; 3 incomplete traces.
- 0 attempts have no source fingerprint; cross-provider asset matches are unavailable for those attempts.
- Storage unavailable: none observed; trace persistence stored-only.
- Archive read: read.
- Source IDs are installation-keyed HMACs over the exact source URL without fragment. Raw origins, paths, query values and the key are omitted. Changed query values, including rotated signatures, do not match. Matching IDs do not prove unchanged file bytes.
- A missing click cannot establish whether Chrome failed to deliver it or collection was unavailable.
- Stages and local receipts do not prove live provider acceptance. Remote objects must be checked separately.
- Same sourceId can correlate attempts across providers; unknown IDs are evidence gaps, not inferred matches.

## Same-asset observations
- Asset 3115fbe957db: google COMPLETED 697e3759-4545-4072-9574-9b6d4b543419; dropbox COMPLETED a32f5810-1112-4bdc-b0a4-455cf69d6966; onedrive COMPLETED 2db1d7af-fdc8-485a-b94b-d75406c166d0; cloudflare UNCERTAIN 9852168a-5a7c-4522-9f54-3a25bdd7d925.
- Asset ee89ba5031d6: cloudflare UNCERTAIN 1bd854aa-af81-4248-969b-6ca27492353a; google COMPLETED d79caee0-ee07-4caa-8b34-31e2d1eeed98; dropbox COMPLETED 2566d55a-9dc2-49e6-ae65-a12ffbf64a65; onedrive COMPLETED 5b091c0b-2920-4d6e-9472-b5609a7b1efb.
- Asset 6f97c4d2b04b: cloudflare UNCERTAIN 485ba2f7-8df7-41ea-825e-c8da503dfe16; google COMPLETED 3a60490a-2459-477e-8ca6-49797b02f83d; onedrive COMPLETED 2fbf40ae-d5b0-4bc1-b661-1d9dee165751; dropbox COMPLETED d86a1c28-fa9b-4a77-9f77-9930ea82accb; google COMPLETED cf359c47-945a-4467-9e24-4809646ebbb6; onedrive COMPLETED 38494fa0-7535-46b0-886a-0352d56c6184; dropbox COMPLETED 7ec95390-1cd9-42d2-a18e-06dccbb2ed66; cloudflare UNCERTAIN 37ae0a0a-9f57-451d-97d6-91aa8d62d638.
- Asset 5249934e5518: cloudflare UNCERTAIN d480981c-9aee-4768-947b-d6c6d3c6a0be; google COMPLETED 616ebe67-5b93-4f96-95d7-66d76de2273b; dropbox COMPLETED 766d59d8-eb5f-4b8a-8283-2f96473091b6; onedrive COMPLETED 892866bf-b337-4537-ae36-61c61852b09f.
- Asset 8f4ffd2749fe: cloudflare UNCERTAIN b0975d48-1df9-4085-b376-42706a51dc2b; dropbox COMPLETED ca2ad8f0-e83e-465f-8660-1b8e8e0c480e; onedrive COMPLETED 6037229a-724d-4dde-a9ac-6d3e7b6060d1; google COMPLETED 8eb32c91-683a-476a-a593-dcf049fe2a93.
- Asset 805a788a8b6b: cloudflare UNCERTAIN 965f188f-a510-402c-b7ef-d37a78b408aa; google COMPLETED 53fbbfd9-6302-4cd2-af00-94c735033e44; onedrive COMPLETED d4a01b6b-1814-49b7-80aa-75499d05c56b; onedrive BLOCKED dbc9c6ef-e18d-461e-93a1-e6af93a4a14c.
- Asset 2e812c616912: cloudflare UNCERTAIN a231d55c-fc42-45f9-9da3-9064499048a5; google COMPLETED 08346101-8281-4a9e-883f-f7d0e0883ccd; dropbox COMPLETED 4477241e-9583-4196-a4cd-dd3a29d8c3e0; onedrive COMPLETED 2ddc766f-2472-4158-afcc-1e6f3102be4e; dropbox COMPLETED 8db5beb0-8997-4bfb-8392-5cb267ba6a47; google COMPLETED 63967edd-1f5a-4a11-baad-0393f43c429d.
- Asset d93280ea2faf: dropbox COMPLETED 9990a3a8-1433-4efc-bbbd-1e1465e79a14; onedrive COMPLETED 87a0fb5b-89d5-4076-b90b-c03be4517f33; google COMPLETED d52afdff-bea2-4315-8d3d-a00ca6c03d2b; cloudflare UNCERTAIN b0492e9d-8ae0-40ea-9650-6bc4e8915b61.
- Asset 25d3f65c0c05: onedrive COMPLETED 05885ceb-6d30-4633-8eee-10f3efc5927a; onedrive BLOCKED 7fcc281a-8696-4203-a7c4-872a2a221b54; dropbox COMPLETED acd0642f-dcca-498f-a144-4036c3831351; google COMPLETED 30ca269d-c5ea-49e9-a3a4-c1c27e4bf7fc; cloudflare UNCERTAIN b8a7298f-b159-449b-9f47-a233dbabefa2.
- Asset f2a4193c142c: onedrive COMPLETED 2996a5ea-8698-49fa-8738-f645dfc21075; dropbox COMPLETED e2bc721c-a0cf-4b74-8d99-1e4ec1faba65; google COMPLETED e1061cb8-1fbe-4c52-bdd2-7bfa1b727639; cloudflare UNCERTAIN 52d7bafc-8f66-46f3-bdd6-afea9c2bb09c; onedrive COMPLETED bccf02cc-4b8c-44ce-bf00-bfd0fc7a258b.
- Asset 8d673ab8406f: onedrive BLOCKED 2294986c-80e1-4784-8d03-4e5f243c2ea9; dropbox COMPLETED 52e7575f-8ce3-4a31-a665-c1a9e81fe7d9.
- Asset e5ff28632f19: onedrive COMPLETED f0e086b9-7fa2-448b-b556-6cd3690af156; google COMPLETED 033241bf-2622-437c-9b02-837a0427ce82; dropbox COMPLETED 05ff82ca-db8b-43ad-bac7-47ea3b592419.
- Asset e51c6518f44f: onedrive COMPLETED 08b4429a-7a49-46cb-83f6-46e96e0fd9ca; dropbox COMPLETED 76a115dc-c1b6-4d78-b41a-77638c57a85d; google COMPLETED c0c789ea-9206-485a-87e8-e7bea79c54d2; google COMPLETED 07249efc-42c3-4a8e-bc4b-b1f9d5e47568; dropbox COMPLETED 19c1833a-aad1-4731-844c-9302847ed750; onedrive COMPLETED c48d1952-6dc8-428f-b091-75cfa52c4ad6; cloudflare UNCERTAIN 5e701738-4433-4cbf-bae8-f5d4355880af.
- Asset abbbfcdfff55: google COMPLETED 5d70ad71-196a-4142-9616-69d033e758a1.
- Asset c028eca0186f: google COMPLETED a620ea75-25aa-4f22-ba78-bb6dd17e06bc; onedrive COMPLETED ba7fed51-e389-4b1b-ae61-5915cb72c9c5; dropbox COMPLETED 8ca9594d-1268-4432-adaf-a25f4bf28dcf; cloudflare UNCERTAIN 79f95765-00a8-4d51-87af-b117df9d9d63.
- Asset 8a7989ca100f: cloudflare UNCERTAIN 2b76322f-dcd4-47ec-94ae-f857e7cb062b; dropbox COMPLETED 7652a91e-f1f6-4696-9741-638ea7b39d57; onedrive COMPLETED 9e068028-b6c6-4916-8ff0-0e4f601485f4; google COMPLETED c9ce49d8-ba10-4b4a-a313-55b834cc22e8.
- Asset b35171019fce: google COMPLETED f41ddbf0-6195-49b2-9b14-94d212819058.
- Asset 14d13951cb70: dropbox BLOCKED f0ac60a1-ec89-49de-90cb-4d7d16bf58df.
- Asset 263e7f2c41dc: onedrive BLOCKED 32fa5273-eb4f-4a7f-9edb-2652581618ac.
- Asset 5a7c547e299f: google incomplete b9649090-7bec-4cea-af4e-81aac03ed017; dropbox incomplete d128e54e-47cc-45a4-a259-b41d21c06729; onedrive incomplete bf039ef5-4e0b-48c7-a518-ea540982c1e7.
