# REDOWN diagnostic summary

Scope: simulated UI fixture; zero genuine provider transfers; stored-only offline export
Collection: 2026-11-11T15:32:40.827Z

## Provider transitions
- google: 3 rows; failure codes {"SOURCE_RETURNED_HTML":3}; last verified receipt unavailable; first later failure 00000000-0000-4000-8000-000000000001 at 2026-11-11T15:32:37.335Z.
- dropbox: 1 rows; failure codes {"QUEUE_STALLED":1}; last verified receipt unavailable; first later failure 00000000-0000-4000-8000-000000000005 at 2026-11-11T15:29:20.712Z.
- onedrive: 2 rows; failure codes {"ONEDRIVE_SOURCE_LENGTH_UNKNOWN":1,"UNCONFIRMED":1}; last verified receipt unavailable; first later failure 00000000-0000-4000-8000-000000000003 at 2026-11-11T15:32:37.336Z.
- cloudflare: 0 rows; failure codes {}; last verified receipt unavailable; first later failure unavailable.

## Correlations and missing evidence
- 1 observed queue/phase stalls; no automatic retry was triggered.
- 5 attempt-only rows; 1 incomplete traces.
- 6 attempts have no source fingerprint; cross-provider asset matches are unavailable for those attempts.
- Storage unavailable: none observed; trace persistence stored-only.
- Archive read: read.
- Source IDs are installation-keyed HMACs over the exact source URL without fragment. Raw origins, paths, query values and the key are omitted. Changed query values, including rotated signatures, do not match. Matching IDs do not prove unchanged file bytes.
- A missing click cannot establish whether Chrome failed to deliver it or collection was unavailable.
- Stages and local receipts do not prove live provider acceptance. Remote objects must be checked separately.
- Same sourceId can correlate attempts across providers; unknown IDs are evidence gaps, not inferred matches.
