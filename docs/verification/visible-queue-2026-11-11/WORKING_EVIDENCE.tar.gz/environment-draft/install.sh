#!/usr/bin/env bash
set -euo pipefail
cd /workspace/REDOWN
npm ci --cache /workspace/.npm-cache --no-audit --no-fund
python3 -m venv /workspace/.venvs/redown
/workspace/.venvs/redown/bin/python -m pip install --cache-dir /workspace/.pip-cache jsonschema==4.26.0
